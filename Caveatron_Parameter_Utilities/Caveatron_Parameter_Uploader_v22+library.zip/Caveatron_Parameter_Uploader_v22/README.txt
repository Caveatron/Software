To run the Caveatron_Parameter_Uploader program, you must download and install the Arduino IDE and then the Teensyduino add-on.

https://www.arduino.cc/en/software
https://www.pjrc.com/teensy/td_download.html

The UTFT folder must be placed in the Arduino libraries folder which is normally located under: Documents/Arduino/libraries
Note that this version of UTFT is customized for the Caveatron. The regular version will not work.